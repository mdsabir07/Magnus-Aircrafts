<?php
/**
 * Template Name: MsiTheme Elementor
 */
the_post();
get_header();
echo "<div class='msitheme-content-elementor'>";
the_content();
echo "</div>";
get_footer();